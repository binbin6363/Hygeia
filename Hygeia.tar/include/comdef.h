/**
 * @filedesc: 
 * 
 * @author: 
 *  bbwang
 * @date: 
 *  
 * @modify:
 *
**/
#ifndef __COMDEF_H__
#define __COMDEF_H__

#include "custype.h"
#define DECLEAR_STR_IDENTIFY(idenfity) extern const char *idenfity;




#endif // __COMDEF_H__
