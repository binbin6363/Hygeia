/**
 * @filedesc: 
 *  client_session.h
 *  compile .dll or .so
 * @author: 
 *  bbwang
 * @date: 
 *  2014/10/26 12:44
 *  
 * @modify:
 *
**/
#include "client_session.h"

namespace hygeia{
namespace user{


static const char *IDENFITY = "CON.HYGEIA.CLIENT_SESSION\0";

ClientSession::ClientSession()
{

}

ClientSession::~ClientSession()
{

}


}// namespace user
} // namespace hygeia

